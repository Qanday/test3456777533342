from keep_alive import keep_alive
import os 
keep_alive()
os.system("chmod +x ffmpeg.sh && ./ffmpeg.sh")