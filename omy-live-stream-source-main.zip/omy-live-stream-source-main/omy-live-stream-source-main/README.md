# [ BRUH STOP FORKING IT STAR IT ALSO ]

# omy-live-stream-source

This is the source code of the live stream playing fire crackling in my youtube channel live [https://www.youtube.com/c/KorryKatti] .

Just deploy it and install the flask package

make a .env file with stream key also ( KEY = "YOUR STREAM KEY" )

To change the video change the video.mp4 file

Thats it



## .ENV file 

just write this in it : ```KEY = "YOUR STREAM KEY"```

# PROPER RUNNING STEPS

1) `git clone https://github.com/korrykatti/omy-live-stream-source/`
2) `cd omy-live-stream-source `
3) `pip install flask`
4) make a .env file 
5) in the .env file make a variable `KEY`
6) Here is the format for the .env file : ``` KEY = "YOUTUBE STREAM KEY" ```
7) Save the .env file
8) then run `python main.py`
9) Tested to work only on linux
